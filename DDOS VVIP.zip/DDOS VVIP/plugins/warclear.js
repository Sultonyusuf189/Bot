let handler = async (m, { conn, command}) => {
await conn.relayMessage(m.chat, {
      scheduledCallCreationMessage: {
            callType: 'AUDIO',
            scheduledTimestampMs: 1,
            title: ""
		}
	}, {})
}

handler.help = ['clear'];
handler.tags = ['tools'];
handler.command = /^(clear)$/i;
handler.owner = true;
module.exports = handler;