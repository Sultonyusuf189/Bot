const fs = require('fs');
const { promisify } = require('util');
const exec = promisify(require('child_process').exec);
const path = require('path');

let handler = async (m, { conn, args }) => {
  if (!args[0]) return conn.reply(m.chat, '```[🔎] What You Will Do? update/send/total!```', m);
  const action = args[0];

  const hackerIntro = `======================
[!] Proxy Updating [!]
10-30 Minute
======================`;


  if (action === "update") {
    try {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Updating... [🚀]',
          body: 'StarsXBot',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: ``
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
      await exec(`node update.js`);
      m.reply("```Proxy Updated```")
    } catch (error) {
      console.error(error);
    }
  } else if (action === "send") {
    const filePath = 'proxy.txt';
    try {
      conn.sendMessage(m.chat, { document: { url: filePath }, fileName: 'proxy.txt', mimetype: 'text/plain' }, { quoted: m });
    } catch (error) {
      console.error(error);
      conn.reply(m.chat, 'Error sending proxy file', m);
    }
  } else if (action === "total") {
    fs.readFile('proxy.txt', 'utf8', (err, data) => {
      if (err) {
        console.error(err);
        return conn.reply(m.chat, 'Error reading proxy list file', m);
      }
  
      const proxies = data.trim().split('\n');
      const totalProxies = proxies.length;
  
      conn.reply(m.chat, `Total proxies: ${totalProxies}`, m);
    });
  } else {
    conn.reply(m.chat, '```[🔎] Invalid action! Choose from update/download/total!```', m);
  }
};

handler.help = ['proxy <action>'];
handler.tags = ['tools'];

handler.command = /^(proxy)$/i;
handler.owner = true;
handler.group = true;

module.exports = handler;
